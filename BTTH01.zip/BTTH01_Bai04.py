toan = float(input("Nhập điểm Toán: "))
van = float(input("Nhập điểm Văn: "))
anh = float(input("Nhập điểm Anh: "))

diem_tb = (toan + van + anh) / 3

print("Điểm trung bình:", round(diem_tb, 2))