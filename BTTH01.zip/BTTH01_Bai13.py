n = int(input("Nhập số lượng số: "))

dem = 0

for i in range(n):
    so = int(input("Nhập số: "))

    if so % 2 == 0:
        dem = dem + 1

print("Có", dem, "số chẵn.")