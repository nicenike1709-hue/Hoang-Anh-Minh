a = float(input("Nhập số a: "))
b = float(input("Nhập số b: "))

if a > b:
    print("Số lớn hơn là:", a)
else:
    print("Số lớn hơn là:", b)