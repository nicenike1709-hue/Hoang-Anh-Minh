import random

bi_mat = random.randint(1, 10)

while True:
    doan = int(input("Đoán số từ 1 đến 10: "))

    if doan == bi_mat:
        print("Đúng rồi!")
        break
    elif doan < bi_mat:
        print("Lớn hơn!")
    else:
        print("Nhỏ hơn!")