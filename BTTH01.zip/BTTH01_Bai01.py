name = "Nguyen Van A"
age = 18
school = "THPT ABC"

print(f"Xin chào, tôi là {name}, năm nay {age} tuổi, đang học tại {school}.")