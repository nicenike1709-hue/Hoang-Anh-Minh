chieu_dai = float(input("Nhập chiều dài: "))
chieu_rong = float(input("Nhập chiều rộng: "))

chu_vi = (chieu_dai + chieu_rong) * 2
dien_tich = chieu_dai * chieu_rong

print("Chu vi là:", chu_vi)
print("Diện tích là:", dien_tich)