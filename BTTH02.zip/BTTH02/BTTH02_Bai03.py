s = input("Nhập chuỗi tiếng Anh: ")

nguyen_am = "aeiou"
dem_nguyen_am = 0
dem_phu_am = 0

for ky_tu in s.lower():
    if ky_tu in nguyen_am:
        dem_nguyen_am += 1
    elif ky_tu.isalpha():
        dem_phu_am += 1

print("Số nguyên âm:", dem_nguyen_am)
print("Số phụ âm:", dem_phu_am)