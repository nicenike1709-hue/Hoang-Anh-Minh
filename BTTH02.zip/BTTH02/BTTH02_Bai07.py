cau = input("Nhập câu: ")

so_tu = len(cau.split())

print("Số từ trong câu là:", so_tu)