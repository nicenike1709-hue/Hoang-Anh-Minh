ds = list(map(int, input("Nhập danh sách số: ").split()))

so_xuat_hien_nhieu_nhat = ds[0]
so_lan = ds.count(ds[0])

for so in ds:
    dem = ds.count(so)

    if dem > so_lan:
        so_xuat_hien_nhieu_nhat = so
        so_lan = dem

print("Phần tử xuất hiện nhiều nhất:", so_xuat_hien_nhieu_nhat)
print("Số lần xuất hiện:", so_lan)