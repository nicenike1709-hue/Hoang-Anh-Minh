ds = list(map(int, input("Nhập danh sách số: ").split()))

ket_qua = [so for so in ds if so > 10]

print("Danh sách các số lớn hơn 10:", ket_qua)