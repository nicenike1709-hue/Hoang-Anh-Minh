s = input("Nhập chuỗi: ")

if s == s[::-1]:
    print("Chuỗi đối xứng")
else:
    print("Chuỗi không đối xứng")