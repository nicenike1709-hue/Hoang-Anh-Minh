s = input("Nhập câu: ")

danh_sach = s.split()

print("Danh sách các từ:", danh_sach)

ket_qua = "-".join(danh_sach)

print("Chuỗi sau khi nối:", ket_qua)