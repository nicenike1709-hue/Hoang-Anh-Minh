ds = list(map(int, input("Nhập danh sách số: ").split()))

ket_qua = []

for so in ds:
    if so not in ket_qua:
        ket_qua.append(so)

print("Danh sách sau khi loại bỏ trùng:", ket_qua)