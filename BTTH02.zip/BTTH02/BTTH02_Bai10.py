ds = list(map(int, input("Nhập danh sách: ").split()))

ds.reverse()

print("Danh sách đảo ngược:", ds)