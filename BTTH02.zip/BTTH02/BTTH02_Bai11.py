ds = list(map(int, input("Nhập danh sách số: ").split()))

tong = 0

for so in ds:
    if so % 2 == 0:
        tong += so

print("Tổng các số chẵn:", tong)