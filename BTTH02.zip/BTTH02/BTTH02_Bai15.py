cau = input("Nhập đoạn văn: ")

# Loại bỏ dấu câu
cau = cau.replace(",", "")
cau = cau.replace(".", "")
cau = cau.replace("!", "")
cau = cau.replace("?", "")

# Chuyển tất cả thành chữ thường
cau = cau.lower()

# Tách thành danh sách từ
ds = cau.split()

# Đếm số lần xuất hiện của từng từ
tan_suat = {}

for tu in ds:
    if tu in tan_suat:
        tan_suat[tu] += 1
    else:
        tan_suat[tu] = 1

# Sắp xếp theo tần suất giảm dần
ket_qua = sorted(tan_suat.items(), key=lambda x: x[1], reverse=True)

# In kết quả
for tu, so_lan in ket_qua:
    print(tu, ":", so_lan)