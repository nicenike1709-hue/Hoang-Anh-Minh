s = input("Nhập chuỗi: ")

print("Độ dài chuỗi là:", len(s))

for ky_tu in s:
    print(ky_tu, ":", s.count(ky_tu))