s = input("Nhập câu: ")

ket_qua = s.title()

print(ket_qua)