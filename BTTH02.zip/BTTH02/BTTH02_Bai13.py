ds1 = list(map(int, input("Nhập danh sách 1: ").split()))
ds2 = list(map(int, input("Nhập danh sách 2: ").split()))

ds = ds1 + ds2

ds.sort()

print("Danh sách sau khi gộp và sắp xếp:", ds)