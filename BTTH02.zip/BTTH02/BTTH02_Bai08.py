ds = list(map(int, input("Nhập danh sách số nguyên: ").split()))

tong = sum(ds)
trung_binh = tong / len(ds)
lon_nhat = max(ds)

print("Tổng:", tong)
print("Trung bình:", trung_binh)
print("Số lớn nhất:", lon_nhat)